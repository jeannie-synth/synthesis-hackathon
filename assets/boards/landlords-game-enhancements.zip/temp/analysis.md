# The Landlord's Game — Enhanced Renderer: Analysis & Specification

---

## Section 1: JSON Data Schema

### 1.1 Top-Level Structure

The game data file (`game-12-monopolist.json`, ~198KB) contains the following top-level keys:

| Key | Type | Description |
|-----|------|-------------|
| `gameId` | `number` | Unique game identifier. Value: `12` |
| `mode` | `string` | Starting game mode. Value: `"Monopolist"` |
| `playerAddresses` | `string[]` | Array of 5 Ethereum wallet addresses identifying each player |
| `turns` | `object[]` | Array of 708 turn/action entries recording every event in the game |
| `roundSnapshots` | `object[]` | Array of 54 snapshots capturing full game state at the end of each round |
| `result` | `object` | Final game outcome data |

### 1.2 Player Addresses

Players are identified by Ethereum addresses, mapped to agent strategy names by index:

| Index | Address | Agent Name |
|-------|---------|------------|
| 0 | `0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266` | Extractive-0 |
| 1 | `0x70997970C51812dc3A010C7d01b50e0d17dc79C8` | Generative-1 |
| 2 | `0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC` | Conditional-2 |
| 3 | `0x90F79bf6EB2c4f870365E785982E1f101E93b906` | FreeRider-3 |
| 4 | `0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65` | Pavlov-4 |

The mapping is done in the HTML via the `STRATEGY_NAMES` array: `['Extractive', 'Generative', 'Conditional', 'FreeRider', 'Pavlov']`. The agent name in turns uses the format `StrategyName-Index` (e.g., `"Extractive-0"`).

### 1.3 Board Layout (40 Spaces)

The board is a 40-space loop (like Monopoly), defined in the HTML's `BOARD` constant. Spaces are organized into 4 sides of 9 spaces each, plus 4 corners:

| Position | Name | Type | Price | Group |
|----------|------|------|-------|-------|
| 0 | Mother Earth | Go | $0 | 0 |
| 1 | Poverty Place | Lot | $60 | 1 |
| 2 | Community Chest | Chest | $0 | 0 |
| 3 | Easy Street | Lot | $60 | 1 |
| 4 | Absolute Necessity | Tax | $50 | 0 |
| 5 | Soakum Lighting Co. | Utility | $150 | 0 |
| 6 | Lonely Lane | Lot | $100 | 2 |
| 7 | Family Emergency | Expense | $50 | 0 |
| 8 | Boomtown | Lot | $100 | 2 |
| 9 | Slambang Trolley | Railroad | $200 | 0 |
| 10 | Jail | Jail | $0 | 0 |
| 11 | Beggarman's Court | Lot | $120 | 3 |
| 12 | Rubeville | Lot | $120 | 3 |
| 13 | The Bowery | Lot | $140 | 4 |
| 14 | Community Bounty | Windfall | $50 | 0 |
| 15 | Rickety Row | Lot | $140 | 4 |
| 16 | Grand Boulevard RR | Railroad | $200 | 0 |
| 17 | Lord Blueblood's | Lot | $160 | 5 |
| 18 | Chance | Chance | $0 | 0 |
| 19 | Crooked Lane | Lot | $160 | 5 |
| 20 | Public Park | Parking | $0 | 0 |
| 21 | La Swelle Hotel | Lot | $180 | 6 |
| 22 | Aqua Pura Water Co. | Utility | $150 | 0 |
| 23 | Gambling Den | Lot | $180 | 6 |
| 24 | Broken Leg RR | Railroad | $200 | 0 |
| 25 | Calamity Avenue | Lot | $200 | 7 |
| 26 | Chance | Chance | $0 | 0 |
| 27 | Easy Money | Lot | $220 | 7 |
| 28 | Luxury Tax | Tax | $75 | 0 |
| 29 | Wall Street | Lot | $220 | 7 |
| 30 | Go to Jail | GoToJail | $0 | 0 |
| 31 | Fairhope Avenue | Lot | $240 | 8 |
| 32 | Arden Avenue | Lot | $240 | 8 |
| 33 | Community Chest | Chest | $0 | 0 |
| 34 | Franceswayland Ave | Lot | $260 | 8 |
| 35 | Coxeyville Short Line | Railroad | $200 | 0 |
| 36 | Chance | Chance | $0 | 0 |
| 37 | The Estates | Lot | $300 | 8 |
| 38 | Supertax | Tax | $100 | 0 |
| 39 | Prosperity Place | Lot | $400 | 8 |

**Space Types:** Go, Lot, Chest, Tax, Utility, Expense, Railroad, Jail, Windfall, Chance, Parking, GoToJail

**Property Groups (with colors in original):**
- Group 0: `#888888` (non-ownable: Go, Jail, Tax, Chance, etc.)
- Group 1: `#8B4513` (Brown — Poverty Place, Easy Street)
- Group 2: `#87CEEB` (Light Blue — Lonely Lane, Boomtown)
- Group 3: `#FF69B4` (Pink — Beggarman's Court, Rubeville)
- Group 4: `#FFA500` (Orange — The Bowery, Rickety Row)
- Group 5: `#FF0000` (Red — Lord Blueblood's, Crooked Lane)
- Group 6: `#FFD700` (Gold — La Swelle Hotel, Gambling Den)
- Group 7: `#228B22` (Green — Calamity Avenue, Easy Money, Wall Street)
- Group 8: `#0000CD` (Blue — Fairhope Ave, Arden Ave, Franceswayland Ave, The Estates, Prosperity Place)

### 1.4 Turn/Action Structure

Each turn entry has the following schema:

```json
{
  "agent": "string",          // Agent name, e.g. "Extractive-0"
  "action": "string",         // Action type
  "details": { ... },         // Action-specific payload
  "timestamp": 1773551639979  // Unix timestamp in milliseconds
}
```

**Action Types (8 unique, 708 total entries):**

| Action | Count | Details Schema | Description |
|--------|-------|----------------|-------------|
| `roll` | 279 | `{ dice: [int, int], position: int, spaceName: string, cash: int }` | Player rolls dice, moves to position |
| `vote` | 260 | `{ inFavor: boolean }` | Player votes on a mode-switch proposal |
| `proposeModeSwitch` | 65 | `{ currentMode: string }` | Player proposes switching game mode |
| `proposalRejected` | 65 | `{}` | Proposal was rejected by vote |
| `build` | 16 | `{ position: int }` | Player builds a house on owned property |
| `buy` | 14 | `{ position: int, price: int }` | Player buys a property |
| `jailWait` | 8 | `{ turnsServed: int }` | Player waits in jail |
| `jailBuyout` | 1 | `{ cost: int }` | Player pays to leave jail |

**Example turn entries by action type:**

**Roll:**
```json
{
  "agent": "Extractive-0",
  "action": "roll",
  "details": {
    "dice": [2, 3],
    "position": 5,
    "spaceName": "Soakum Lighting Co.",
    "cash": 500
  },
  "timestamp": 1773551639979
}
```

**Buy:**
```json
{
  "agent": "Extractive-0",
  "action": "buy",
  "details": {
    "position": 5,
    "price": 150
  },
  "timestamp": 1773551644011
}
```

**Build:**
```json
{
  "agent": "Extractive-0",
  "action": "build",
  "details": {
    "position": 11
  },
  "timestamp": 1773551744816
}
```

**Propose Mode Switch:**
```json
{
  "agent": "Generative-1",
  "action": "proposeModeSwitch",
  "details": {
    "currentMode": "Monopolist"
  },
  "timestamp": 1773551652076
}
```

**Vote:**
```json
{
  "agent": "Extractive-0",
  "action": "vote",
  "details": {
    "inFavor": false
  },
  "timestamp": 1773551656096
}
```

**Proposal Rejected:**
```json
{
  "agent": "Generative-1",
  "action": "proposalRejected",
  "details": {},
  "timestamp": 1773551664167
}
```

**Jail Wait:**
```json
{
  "agent": "Extractive-0",
  "action": "jailWait",
  "details": {
    "turnsServed": 1
  },
  "timestamp": 1773552269791
}
```

**Jail Buyout:**
```json
{
  "agent": "Extractive-0",
  "action": "jailBuyout",
  "details": {
    "cost": 50
  },
  "timestamp": 1773554143577
}
```

### 1.5 Round Snapshots

Each snapshot captures the full game state at the end of a round:

```json
{
  "round": 1,
  "players": [
    {
      "address": "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
      "cash": 350,
      "position": 5,
      "inJail": false,
      "netWorth": 350
    },
    // ... 4 more players
  ],
  "treasury": 0,
  "mode": "Monopolist"
}
```

- 54 snapshots total (rounds 1–45, with some rounds having multiple snapshots or the numbering includes sub-rounds)
- Player attributes per snapshot: `address`, `cash`, `position`, `inJail`, `netWorth`
- Global state: `treasury` (always 0 in this game), `mode` (always "Monopolist" — no mode switch succeeded)

### 1.6 Result Object

```json
{
  "winner": "0x90F79bf6EB2c4f870365E785982E1f101E93b906",
  "mode": "Monopolist",
  "rounds": 45,
  "turnsTaken": 229,
  "giniCoefficient": 0.21677978339350182,
  "finalBalances": [326, 500, 228, 2046, 1025],
  "treasuryFinal": 0,
  "netWorths": [1686, 500, 1668, 2046, 1025]
}
```

- **Winner:** FreeRider-3 (address `0x90F79bf6EB2c4f870365E785982E1f101E93b906`, index 3)
- **Final net worths:** Extractive-0: $1686, Generative-1: $500, Conditional-2: $1668, FreeRider-3: $2046, Pavlov-4: $1025
- **Gini coefficient:** 0.2168 (moderate inequality)
- **Note:** `turnsTaken` (229) differs from `turns.length` (708) because votes, proposals, and rejections are counted separately from "game turns"

### 1.7 Dice Data

Dice rolls are embedded in `roll` action details as `dice: [int, int]` — two six-sided dice. Examples from the data:
- `[2, 3]` → total 5
- `[5, 6]` → total 11
- `[1, 1]` → doubles

---

## Section 2: Current HTML/JS Features Inventory

### 2.1 Application Structure

Single-page HTML application with:
- Embedded CSS in `<style>` block (~240 lines)
- Embedded JavaScript in `<script>` block (~700 lines)
- No external dependencies (vanilla HTML/CSS/JS)
- Two main views: Load Screen and Game Viewer

### 2.2 Load Screen Features

- **Title display:** "The Landlord's Game" with "Replay Viewer" subtitle
- **Drag-and-drop zone:** Drop a JSON game file to load
- **File picker button:** "Choose File" triggers hidden `<input type="file">`
- **URL parameter loading:** `?game=path/to/game.json` auto-loads from URL
- **Visual feedback:** Drop zone highlights on dragover (`.dragover` class)

### 2.3 Game Viewer Layout

**Header:**
- Game title "The Landlord's Game"
- "Load Game" button (to load a different game file)
- Round label (e.g., "Round 12")
- Mode badge ("Monopolist" in red, or "Prosperity" in green)
- Treasury display

**Main Layout (flex row):**
- **Board container** (left, flex: 1): SVG board visualization
- **Sidebar** (right, 320px fixed width):
  - Player cards section
  - Info panel (game metadata)
  - Event ticker (scrollable action log)

**Controls Bar (bottom):**
- Previous turn button (⏪)
- Play/Pause toggle button (▶/⏸)
- Next turn button (⏩)
- Speed slider (range 1–50, default 8x)
- Progress bar (clickable for seeking)
- Turn counter label ("Turn X / Y")

### 2.4 Board Rendering (SVG)

- **SVG viewBox:** 720×720 pixels
- **Layout:** Classic Monopoly-style square board
  - 4 corner spaces (52×52 px each)
  - 9 spaces per side (excluding corners)
  - Side space width: `(720 - 2*52) / 9 ≈ 68.4px`
  - Side space depth: 67px (extending inward)
- **Space rendering:**
  - Cream/beige background (`#f0e6d0`) with brown border (`#8b7355`)
  - Color band (10px) on the inner edge for Lot-type spaces, colored by group
  - Space name label (truncated to 14 chars + ".." if > 16 chars)
  - Price label for purchasable spaces
  - Owner indicator bar (4px tall, colored by owner, at bottom of space)
  - House indicators (8×8 green squares)
- **Center area:** "THE LANDLORD'S GAME" text + mode label
- **Token layer:** Colored circles (r=8) with player index number, spread in circular pattern to avoid overlap
  - Jail state shown with white stroke and reduced opacity

### 2.5 Player Cards

Each player card displays:
- Colored dot + strategy name
- Jail status indicator `[JAIL]`
- Winner indicator `[WINNER]` (at game end)
- Stats grid: Cash, Net Worth, Position (space name), Properties count
- Wealth bar (proportional to max net worth, colored by player)
- Active player highlighting (gold border + background tint)
- Winner highlighting (gold border + stronger background tint)

### 2.6 Info Panel

Static game metadata displayed after loading:
- Game ID
- Mode
- Total turns count
- Result (winner strategy name + round count)
- Gini coefficient

### 2.7 Event Ticker

Scrollable log of all processed turns with:
- Agent name (colored by player)
- Action description text:
  - Roll: `[D1+D2] lands on SpaceName`
  - Buy: `buys PropertyName ($Price)` (highlighted)
  - Build: `builds house on PropertyName` (highlighted)
  - ProposeModeSwitch: `proposes switch from CurrentMode` (highlighted)
  - Vote: `votes YES/NO`
  - ProposalRejected: `proposal REJECTED (turn lost)` (highlighted)
  - ProposalPassed: `proposal PASSED! Mode: NewMode` (highlighted)
  - JailWait: `waits in jail (turn N)`
  - JailBuyout: `pays $Cost to leave jail` (highlighted)
- Highlighted entries have red-tinted background
- Auto-scrolls to bottom on new entries

### 2.8 Game State Management

- **State object:** Tracks `players[]`, `properties{}`, `treasury`, `mode`, `round`
- **Player state:** `address`, `cash`, `position`, `inJail`, `netWorth`, `strategy`
- **Property state:** `pos → { owner (player index), houses }`
- **Initial state:** All players start with $500 cash, position 0, no jail
- **Turn application (`applyTurn`):** Updates state based on action type
- **Snapshot synchronization:** Uses `findSnapshotNear()` to sync with round snapshots (approximate mapping based on turn density)
- **Net worth recalculation:** Cash + sum of owned property prices + houses × $50

### 2.9 Playback System

- **Forward playback:** Sequential turn application with configurable speed
- **Rewind:** Full replay from start (re-initializes state, replays all turns up to target)
- **Play/Pause toggle:** Timer-based auto-advance
- **Speed control:** 1–50 turns/second (minimum 20ms interval)
- **Progress bar seeking:** Click to jump to any point (percentage-based)
- **Keyboard shortcuts:** Space (play/pause), Left arrow (prev), Right arrow (next)

### 2.10 CSS Styling Approach

- **CSS custom properties** for theming (`:root` variables)
- **Dark theme:** Navy/dark blue backgrounds (`#1a1a2e`, `#16213e`)
- **Color scheme:** Red accent (`#e94560`), gold (`#f5c842`), green (`#4ecca3`)
- **Typography:** Courier New monospace throughout
- **Layout:** Flexbox-based responsive layout
- **Transitions:** Smooth wealth bar width, border color changes
- **Board:** Green felt background (`#2a5a3a`), cream spaces

### 2.11 Features That MUST Be Preserved

1. ✅ JSON file loading (drag-drop, file picker, URL parameter)
2. ✅ Load screen with all three loading methods
3. ✅ SVG board rendering with all 40 spaces
4. ✅ Space color bands by property group
5. ✅ Property ownership indicators
6. ✅ House/building indicators on properties
7. ✅ Player token positioning with overlap avoidance
8. ✅ Jail state visual indication on tokens
9. ✅ Player cards with all stats (cash, net worth, position, properties)
10. ✅ Active player highlighting
11. ✅ Winner indication at game end
12. ✅ Wealth bars on player cards
13. ✅ Info panel with game metadata
14. ✅ Event ticker with formatted action descriptions
15. ✅ Highlighted important events in ticker
16. ✅ Playback controls (prev, play/pause, next)
17. ✅ Speed slider (1–50x)
18. ✅ Progress bar with click-to-seek
19. ✅ Keyboard shortcuts (Space, Arrow keys)
20. ✅ Turn counter display
21. ✅ Round label display
22. ✅ Mode badge (Monopolist/Prosperity)
23. ✅ Treasury display
24. ✅ Center board text
25. ✅ "Load Game" button in header for switching files
26. ✅ Game state reconstruction from turns + snapshot sync
27. ✅ Net worth recalculation from properties

---

## Section 3: Design Specification — Alien: Isolation Inspired Aesthetic

### 3.1 Color Palette

Based on research of the Alien: Isolation UI and the Sevastolink terminal theme:

| Role | Hex Code | Description |
|------|----------|-------------|
| **Background (deepest)** | `#0a0a0a` | Near-black, main page background |
| **Panel background** | `#0d1a0d` | Very dark green-black for panels |
| **Board background** | `#0c1f0c` | Dark green for the board felt area |
| **Space background** | `#1a2e1a` | Muted dark green for board spaces |
| **Space border** | `#2a4a2a` | Slightly lighter green for borders |
| **Primary text** | `#33ff33` | Classic terminal green (bright) |
| **Secondary text** | `#1a9a1a` | Dimmed green for less important text |
| **Dim/muted text** | `#0d660d` | Very dim green for labels |
| **Accent (amber/warning)** | `#f07826` | Alien "Acid Blood" orange — for highlights, active states |
| **Accent secondary** | `#ff9933` | Warm amber for secondary highlights |
| **Danger/alert** | `#cc0000` | Red for critical alerts, jail states |
| **Seegson green** | `#05b669` | Bright teal-green for special highlights |
| **Terminal green (glow)** | `#00ff41` | Bright phosphor green for glow effects |
| **White (rare)** | `#c0c0c0` | Muted white, used sparingly |
| **Border glow** | `#33ff3322` | Semi-transparent green for border glows |

### 3.2 Typography

**Primary font stack (terminals/UI):**
```css
font-family: 'VT323', 'Share Tech Mono', 'Courier New', monospace;
```

**Secondary font stack (headings/logo):**
```css
font-family: 'Space Mono', 'Share Tech Mono', 'Courier New', monospace;
```

**Google Fonts import:**
```css
@import url('https://fonts.googleapis.com/css2?family=VT323&family=Share+Tech+Mono&family=Space+Mono:wght@400;700&display=swap');
```

- **VT323:** Primary UI font — authentic CRT terminal look, inspired by DEC VT320
- **Share Tech Mono:** Fallback monospace with industrial feel
- **Space Mono:** For headings and the logo — slightly more refined but still technical

### 3.3 CRT/Scanline Overlay CSS Technique

**Scanline overlay using `::after` pseudo-element:**
```css
.crt-overlay::after {
  content: '';
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: repeating-linear-gradient(
    0deg,
    rgba(0, 0, 0, 0.15) 0px,
    rgba(0, 0, 0, 0.15) 1px,
    transparent 1px,
    transparent 3px
  );
  pointer-events: none;
  z-index: 9999;
}
```

**Screen flicker animation:**
```css
@keyframes flicker {
  0%   { opacity: 0.97; }
  5%   { opacity: 0.95; }
  10%  { opacity: 0.98; }
  15%  { opacity: 0.96; }
  20%  { opacity: 0.99; }
  50%  { opacity: 0.96; }
  80%  { opacity: 0.98; }
  90%  { opacity: 0.95; }
  100% { opacity: 0.98; }
}

.crt-flicker {
  animation: flicker 0.15s infinite;
}
```

**Vignette effect (darkened edges):**
```css
.crt-vignette::before {
  content: '';
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: radial-gradient(
    ellipse at center,
    transparent 60%,
    rgba(0, 0, 0, 0.6) 100%
  );
  pointer-events: none;
  z-index: 9998;
}
```

**Text glow effect:**
```css
.glow-text {
  text-shadow:
    0 0 5px #33ff33,
    0 0 10px #33ff3388,
    0 0 20px #33ff3344;
}
```

**Phosphor text rendering:**
```css
.phosphor {
  color: #33ff33;
  text-shadow: 0 0 5px #33ff33, 0 0 10px rgba(51, 255, 51, 0.5);
}
```

### 3.4 Glow and Flicker Effects

**Element border glow:**
```css
.panel-glow {
  border: 1px solid #33ff3344;
  box-shadow:
    0 0 5px #33ff3322,
    inset 0 0 5px #33ff3311;
}
```

**Active/highlighted element glow (amber):**
```css
.active-glow {
  border-color: #f07826;
  box-shadow:
    0 0 8px #f0782644,
    inset 0 0 4px #f0782622;
}
```

**Subtle background noise (optional):**
```css
.noise-bg {
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E");
}
```

---

## Section 4: Enhancement Plan

### 4.1 "Last Action Taken" Display

**On Player Cards:**
- Add a new row below the stats grid showing the player's most recent action
- Format: `"Last: [dice icon] Rolled [3+4] → Boomtown"` or `"Last: Bought Poverty Place ($60)"`
- Style with dimmed green text, slightly smaller font
- Track `lastAction` per player in the state object by recording the most recent turn for each agent

**On Board (Space Annotations):**
- When a player lands on a space (roll action), briefly highlight that space with a green glow pulse
- Show a small annotation near the space indicating what happened (e.g., "💰 BOUGHT" or "🏠 BUILT")
- Annotations fade after 3 seconds or on next turn advance
- Use SVG text elements positioned near the space with CSS animation for fade-in/out

### 4.2 Dice Rolling Animation

**Design (matching Alien: Isolation aesthetic):**
- Two dice displayed in the board center area (or a dedicated overlay)
- Dice rendered as monochrome green wireframe cubes on dark background
- Rolling animation: rapid number cycling (slot-machine style) for 0.5–1 second
- Final values displayed with a green glow pulse
- Dice values shown as ASCII-art dot patterns inside bordered squares
- Format: `⚀⚁⚂⚃⚄⚅` Unicode dice faces, or custom SVG dot patterns

**Implementation approach:**
```
┌─────┐ ┌─────┐
│ ●   │ │ ● ● │
│  ●  │ │     │
│   ● │ │ ● ● │
└─────┘ └─────┘
  [3]     [4]
```
- Use CSS `@keyframes` for the rolling animation (cycling through random numbers)
- Trigger on each `roll` action during playback
- Green phosphor glow on the dice borders and pips
- Brief flash/pulse when dice settle on final value
- Duration scales with playback speed (shorter at higher speeds)

### 4.3 Logo Design & Integration

**Logo concept: "THE LANDLORD'S GAME" in Alien: Isolation style**
- Custom SVG logo
- Typography: Angular, industrial, uppercase
- Color: Primary terminal green (`#33ff33`) with glow effect
- Subtle scanline texture overlay on the text
- Optional: Small geometric/industrial decorative elements (brackets, lines, dots)
- Dimensions: ~400×60px for header, larger version for load screen

**Integration points:**
- Load screen: Large centered logo replacing the plain `<h1>`
- Header: Smaller logo replacing the text title
- Board center: Subtle watermark version (very low opacity)
- `logo.svg` saved as separate file in `final/` directory

### 4.4 Board Visual Enhancements

**Overall board transformation:**
- Replace cream/beige space backgrounds with dark green (`#1a2e1a`)
- Replace brown borders with dim green (`#2a4a2a`)
- Board felt area: Very dark green (`#0c1f0c`) instead of bright green
- Add subtle grid lines or circuit-board-like patterns in the center area
- Corner spaces get special treatment (slightly brighter, with icons)

**Space enhancements:**
- Property group color bands: Keep but add glow effect matching the group color
- Space names: Green phosphor text with subtle glow
- Price labels: Dim amber text
- Owner indicators: Glowing bar with player color + pulsing effect
- House indicators: Replace green squares with small glowing amber/green dots or chevrons

**Token enhancements:**
- Replace solid circles with hexagonal or diamond shapes
- Add outer glow ring in player color
- Jail state: Red pulsing border instead of white stroke
- Active player token: Brighter glow, slight scale-up animation

**Center area:**
- Logo watermark (very dim)
- Mode label with appropriate glow (red for Monopolist, green for Prosperity)
- Dice display area for rolling animation

### 4.5 Player Card Redesign

**Layout changes:**
- Dark panel background (`#0d1a0d`) with green border glow
- Player name in bright green with colored dot
- Stats displayed in terminal-style format:
  ```
  CASH.........$1,250
  NET WORTH....$2,450
  POSITION.....Boomtown
  PROPERTIES...3
  ```
- Wealth bar: Thin glowing line instead of solid bar
- Active player: Amber border glow + "▶ ACTIVE" indicator
- Winner: Special gold/amber treatment with "★ WINNER" badge

**New "Last Action" section:**
- Below stats, separated by a thin green line
- Shows formatted last action with appropriate icon:
  - 🎲 Rolled [3+4] → Boomtown
  - 💰 Bought Poverty Place ($60)
  - 🏗 Built on Beggarman's Court
  - 🗳 Voted NO on mode switch
  - ⛓ Waiting in jail (turn 2)
  - 💸 Paid $50 to leave jail
- Dim green text, updates with each turn

### 4.6 Additional UI Enhancements

**Controls bar:**
- Dark background with green border top
- Buttons: Dark with green border, green text, amber on hover/active
- Progress bar: Green fill on dark track
- Speed label: Green text

**Event ticker:**
- Green text on dark background
- Agent names in their player color with glow
- Highlighted events: Amber background tint instead of red
- Monospace terminal-style formatting
- Optional: Prefix each entry with a timestamp or turn number

**Header:**
- Dark background with subtle bottom border glow
- Mode badge: Keep red/green but add glow effect
- Round/Treasury labels in dim green

**Load screen:**
- Full CRT effect (scanlines + vignette + flicker)
- Large glowing logo
- Drop zone with dashed green border, green text
- "Choose File" button: Green border, green text, amber on hover
- Subtle animated background (slow scanline sweep or static noise)

### 4.7 Animation & Transition Summary

| Element | Animation | Duration | Trigger |
|---------|-----------|----------|---------|
| Scanlines | Continuous overlay | Infinite | Always on |
| Screen flicker | Subtle opacity variation | 0.15s loop | Always on |
| Dice roll | Number cycling → settle | 0.5–1s | On `roll` action |
| Space highlight | Green glow pulse | 1.5s | On player landing |
| Action annotation | Fade in → hold → fade out | 3s total | On action at space |
| Token movement | Position transition | 0.3s | On position change |
| Active player card | Border glow pulse | 1s loop | While active |
| Wealth bar | Width transition | 0.5s | On value change |
| Mode badge | Color transition | 0.3s | On mode change |

### 4.8 Performance Considerations

- Scanline overlay uses `pointer-events: none` to not interfere with interactions
- Flicker animation uses `opacity` only (GPU-composited, no layout thrash)
- Dice animation should be skippable at high playback speeds (>20x)
- SVG board elements use `id` attributes for efficient DOM updates
- Minimize DOM manipulation in the ticker at high speeds (batch updates or limit visible entries)
- Consider `will-change: transform` on animated elements
- CRT effects can be toggled off for accessibility/performance

---

## Appendix: File Structure Reference

```
project/
├── final/
│   ├── index.html          # Enhanced game renderer (single file, embedded CSS/JS)
│   ├── logo.svg            # Custom SVG logo for "The Landlord's Game"
├── temp/
│   └── analysis.md         # This document
```
