import json
from collections import Counter

with open('game-12-monopolist.json', 'r') as f:
    data = json.load(f)

print("=" * 80)
print("PLAYER ADDRESSES:")
print("=" * 80)
for i, addr in enumerate(data['playerAddresses']):
    print(f"  [{i}]: {addr}")

print("\n" + "=" * 80)
print("ROUND SNAPSHOTS - First snapshot (full):")
print("=" * 80)
snap0 = data['roundSnapshots'][0]
print(json.dumps(snap0, indent=2))

print("\n" + "=" * 80)
print("ROUND SNAPSHOTS - Second snapshot (full):")
print("=" * 80)
snap1 = data['roundSnapshots'][1]
print(json.dumps(snap1, indent=2))

print("\n" + "=" * 80)
print("ROUND SNAPSHOTS - Last snapshot (full):")
print("=" * 80)
snapLast = data['roundSnapshots'][-1]
print(json.dumps(snapLast, indent=2))

print("\n" + "=" * 80)
print("RESULT (full):")
print("=" * 80)
print(json.dumps(data['result'], indent=2))

print("\n" + "=" * 80)
print("ALL UNIQUE ACTION VALUES:")
print("=" * 80)
action_counter = Counter()
for turn in data['turns']:
    action_counter[turn['action']] += 1
for action, count in action_counter.most_common():
    print(f"  {action}: {count}")

print("\n" + "=" * 80)
print("SAMPLE TURNS BY ACTION TYPE:")
print("=" * 80)
seen_actions = set()
for turn in data['turns']:
    a = turn['action']
    if a not in seen_actions:
        seen_actions.add(a)
        print(f"\n--- Action: {a} ---")
        print(json.dumps(turn, indent=2)[:600])

print("\n" + "=" * 80)
print("ALL UNIQUE AGENT NAMES:")
print("=" * 80)
agents = set()
for turn in data['turns']:
    agents.add(turn['agent'])
for a in sorted(agents):
    print(f"  {a}")

print("\n" + "=" * 80)
print("ALL UNIQUE SPACE NAMES (from roll actions):")
print("=" * 80)
space_names = set()
positions_to_names = {}
for turn in data['turns']:
    if 'spaceName' in turn.get('details', {}):
        sn = turn['details']['spaceName']
        pos = turn['details'].get('position')
        space_names.add(sn)
        if pos is not None:
            positions_to_names[pos] = sn
for pos in sorted(positions_to_names.keys()):
    print(f"  Position {pos}: {positions_to_names[pos]}")

print("\n" + "=" * 80)
print("ROUND SNAPSHOT PLAYER STRUCTURE (first player in first snapshot):")
print("=" * 80)
if 'players' in snap0:
    if isinstance(snap0['players'], list):
        print(json.dumps(snap0['players'][0], indent=2))
    elif isinstance(snap0['players'], dict):
        first_key = list(snap0['players'].keys())[0]
        print(f"Key: {first_key}")
        print(json.dumps(snap0['players'][first_key], indent=2))
