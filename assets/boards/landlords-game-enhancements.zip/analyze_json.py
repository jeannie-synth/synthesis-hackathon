import json

with open('game-12-monopolist.json', 'r') as f:
    data = json.load(f)

print("=" * 80)
print("TOP-LEVEL KEYS AND TYPES:")
print("=" * 80)
for key in data:
    val = data[key]
    if isinstance(val, list):
        print(f"  {key}: list (length {len(val)})")
        if len(val) > 0:
            print(f"    First item type: {type(val[0]).__name__}")
            if isinstance(val[0], dict):
                print(f"    First item keys: {list(val[0].keys())}")
    elif isinstance(val, dict):
        print(f"  {key}: dict (keys: {list(val.keys())})")
    else:
        print(f"  {key}: {type(val).__name__} = {repr(val)[:200]}")

print("\n" + "=" * 80)
print("BOARD / SPACES:")
print("=" * 80)
if 'board' in data:
    board = data['board']
    if isinstance(board, dict):
        print(f"Board keys: {list(board.keys())}")
        for bk in board:
            bv = board[bk]
            if isinstance(bv, list):
                print(f"  {bk}: list (length {len(bv)})")
                if len(bv) > 0:
                    print(f"    First: {json.dumps(bv[0], indent=2)[:500]}")
                    if len(bv) > 1:
                        print(f"    Second: {json.dumps(bv[1], indent=2)[:500]}")
            else:
                print(f"  {bk}: {repr(bv)[:200]}")
    elif isinstance(board, list):
        print(f"Board is a list of {len(board)} items")
        for i, item in enumerate(board[:3]):
            print(f"  [{i}]: {json.dumps(item, indent=2)[:300]}")

if 'spaces' in data:
    spaces = data['spaces']
    print(f"Spaces: list of {len(spaces)} items")
    for i, sp in enumerate(spaces[:5]):
        print(f"  [{i}]: {json.dumps(sp, indent=2)[:300]}")
    print(f"  ... last: {json.dumps(spaces[-1], indent=2)[:300]}")

print("\n" + "=" * 80)
print("PLAYERS:")
print("=" * 80)
if 'players' in data:
    players = data['players']
    if isinstance(players, list):
        print(f"Players: list of {len(players)}")
        for p in players:
            print(f"  {json.dumps(p, indent=2)[:500]}")
    elif isinstance(players, dict):
        print(f"Players keys: {list(players.keys())}")
        for pk in players:
            print(f"  {pk}: {json.dumps(players[pk], indent=2)[:500]}")

print("\n" + "=" * 80)
print("TURNS / ACTIONS / EVENTS:")
print("=" * 80)
if 'turns' in data:
    turns = data['turns']
    print(f"Turns: list of {len(turns)} items")
    if len(turns) > 0:
        print(f"  First turn: {json.dumps(turns[0], indent=2)[:1000]}")
        print(f"  Second turn: {json.dumps(turns[1], indent=2)[:1000]}")
        print(f"  Last turn: {json.dumps(turns[-1], indent=2)[:1000]}")

if 'actions' in data:
    actions = data['actions']
    print(f"Actions: list of {len(actions)} items")
    if len(actions) > 0:
        print(f"  First: {json.dumps(actions[0], indent=2)[:500]}")
        print(f"  Last: {json.dumps(actions[-1], indent=2)[:500]}")

if 'events' in data:
    events = data['events']
    print(f"Events: list of {len(events)} items")
    if len(events) > 0:
        print(f"  First: {json.dumps(events[0], indent=2)[:500]}")

if 'history' in data:
    history = data['history']
    print(f"History: list of {len(history)} items")
    if len(history) > 0:
        print(f"  First: {json.dumps(history[0], indent=2)[:500]}")

print("\n" + "=" * 80)
print("DICE DATA:")
print("=" * 80)
# Search for dice-related keys at any level
def find_dice_keys(obj, path=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if 'dice' in k.lower() or 'roll' in k.lower():
                print(f"  Found at {path}.{k}: {repr(v)[:200]}")
            if isinstance(v, (dict, list)):
                find_dice_keys(v, f"{path}.{k}")
    elif isinstance(obj, list) and len(obj) > 0:
        find_dice_keys(obj[0], f"{path}[0]")

find_dice_keys(data)

print("\n" + "=" * 80)
print("ALL UNIQUE ACTION TYPES (if turns have actions):")
print("=" * 80)
if 'turns' in data:
    action_types = set()
    for turn in data['turns']:
        if isinstance(turn, dict):
            if 'actions' in turn:
                for action in turn['actions']:
                    if isinstance(action, dict) and 'type' in action:
                        action_types.add(action['type'])
            if 'type' in turn:
                action_types.add(turn['type'])
    print(f"  Action types: {sorted(action_types)}")

# Check for any other interesting top-level structures
print("\n" + "=" * 80)
print("FULL TOP-LEVEL STRUCTURE DUMP (truncated values):")
print("=" * 80)
for key in data:
    val = data[key]
    if isinstance(val, (str, int, float, bool)):
        print(f"  {key} = {repr(val)}")
    elif isinstance(val, list):
        print(f"  {key} = list[{len(val)}]")
    elif isinstance(val, dict):
        print(f"  {key} = dict{{{', '.join(list(val.keys())[:10])}}}")
